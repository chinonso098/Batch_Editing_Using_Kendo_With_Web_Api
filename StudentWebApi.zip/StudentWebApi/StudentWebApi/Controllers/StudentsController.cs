﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web.Http;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Newtonsoft.Json;
using System.Collections;

namespace StudentWebApi.Controllers
{
    public class StudentsController : ApiController
    {
        private StudentEntities db = new StudentEntities();

        // GET: api/Students
        [System.Web.Http.HttpGet]
        public IQueryable<Student> GetStudents()
        {
            return db.Students;
        }

        // GET: api/Students/5
        //[ResponseType(typeof(Student))]
        //public IHttpActionResult GetStudent(int id)
        //{
        //    Student student = db.Students.Find(id);
        //    if (student == null)
        //    {
        //        return NotFound();
        //    }

        //    return Ok(student);
        //}
        [System.Web.Http.HttpGet]
        public IHttpActionResult Students_Read(int page, int pageSize)
       {
            var request = new DataSourceRequest() {Page = page, PageSize=pageSize};

            using (var northwind = new StudentEntities())
            {
                IQueryable<Student> student = northwind.Students;
                DataSourceResult result = student.ToDataSourceResult(request);
                //return View("Index",result);
                return Json(result);
            }
        }

        [System.Web.Http.HttpPost]
        public  IHttpActionResult Students_Create(ArrayList inputData)
        {
            var request = JsonConvert.DeserializeObject<DataSourceRequest>(inputData[0].ToString());
            var students = new List<Student>();

            for (int i = 1; i<inputData.Count; i++)
            {
                var tempStudent = new Student();
                tempStudent = JsonConvert.DeserializeObject<Student>(inputData[i].ToString());
                students.Add(tempStudent);
            }

            // Will keep the inserted entitites here. Used to return the result later.
            var entities = new List<Student>();
            if (ModelState.IsValid)
            {
                using (var northwind = new StudentEntities())
                {
                    foreach (var student in students)
                    {
                        // Create a new Student entity and set its properties from the posted StudentViewModel.
                        var entity = new Student
                        {
                            Studentid = student.Studentid,
                            Firstname = student.Firstname,
                            Lastname = student.Lastname,
                            Age = student.Age
                        };
                        // Add the entity.
                        northwind.Students.Add(entity);
                        // Store the entity for later use.
                        entities.Add(entity);
                    }
                    // Insert the entities in the database.
                    northwind.SaveChanges();
                }
            }

            return Json(db.Students);
        }

        [System.Web.Http.HttpPut]
        public IHttpActionResult Students_Update(ArrayList inputData)
        {
            var request = JsonConvert.DeserializeObject<DataSourceRequest>(inputData[0].ToString());
            var students = new List<Student>();

            for (int i = 1; i < inputData.Count; i++)
            {
                var tempStudent = new Student();
                tempStudent = JsonConvert.DeserializeObject<Student>(inputData[i].ToString());
                students.Add(tempStudent);
            }

            // Will keep the inserted entitites here. Used to return the result later.
            var entities = new List<Student>();
            if (ModelState.IsValid)
            {
                using (var northwind = new StudentEntities())
                {
                    foreach (var student in students)
                    {
                        var entity = new Student
                        {
                            Id = student.Id,
                            Studentid = student.Studentid,
                            Firstname = student.Firstname,
                            Lastname = student.Lastname,
                            Age = student.Age
                        };

                        entities.Add(entity);
                        db.Students.Attach(entity);
                        db.Entry(entity).State = EntityState.Modified;
                    }
                    db.SaveChanges();
                }
            }
            // Return the updated entities. Also return any validation errors.
            return Json(db.Students);
        }

        // PUT: api/Students/5
        //[ResponseType(typeof(void))]
        //public IHttpActionResult PutStudent(int id, Student student)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }

        //    if (id != student.Id)
        //    {
        //        return BadRequest();
        //    }

        //    db.Entry(student).State = EntityState.Modified;

        //    try
        //    {
        //        db.SaveChanges();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!StudentExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return StatusCode(HttpStatusCode.NoContent);
        //}

        // POST: api/Students
        //[ResponseType(typeof(Student))]
        //public IHttpActionResult PostStudent(Student student)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }

        //    db.Students.Add(student);
        //    db.SaveChanges();

        //    return CreatedAtRoute("DefaultApi", new { id = student.Id }, student);
        //}

        // DELETE: api/Students/5
        //[ResponseType(typeof(Student))]
        //public IHttpActionResult DeleteStudent(int id)
        //{
        //    Student student = db.Students.Find(id);
        //    if (student == null)
        //    {
        //        return NotFound();
        //    }

        //    db.Students.Remove(student);
        //    db.SaveChanges();

        //    return Ok(student);
        //}

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool StudentExists(int id)
        {
            return db.Students.Count(e => e.Id == id) > 0;
        }
    }
}